import { ForgotPasswordPage } from "@/modules/Authentication/ForgotPassword";

export default function Page() {
  return <ForgotPasswordPage />;
}
