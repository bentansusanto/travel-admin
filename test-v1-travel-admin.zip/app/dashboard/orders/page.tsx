import { OrderPage } from "@/modules/Orders";

export default function OrdersV1() {
  return <OrderPage />;
}
