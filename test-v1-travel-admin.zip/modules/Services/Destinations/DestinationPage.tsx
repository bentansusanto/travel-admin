export const DestinationPage = () => {
  return (
    <div>
      <h1>Destination Page</h1>
    </div>
  );
};
