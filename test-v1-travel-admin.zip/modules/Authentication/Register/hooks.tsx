"use client";
import { useRegisterMutation } from "@/store/services/auth.service";
import { useFormik } from "formik";
import { toast } from "sonner";
import { initialRegisterValues, registerSchema } from "./schema";

export const HookRegister = () => {
  const [register, { isLoading }] = useRegisterMutation();

  const formik = useFormik({
    initialValues: initialRegisterValues,
    validate: (values) => {
      const result = registerSchema.safeParse(values);
      if (!result.success) {
        const errors: Record<string, string> = {};
        result.error.issues.forEach((issue) => {
          if (issue.path[0]) {
            errors[issue.path[0] as string] = issue.message;
          }
        });
        return errors;
      }
      return {};
    },
    onSubmit: async (values) => {
      try {
        await register({ ...values, site: "admin" }).unwrap();
        localStorage.setItem("medisuite_verify_email", values.email);

        toast.success("Registration successful! Check your email for verification.");
        formik.resetForm();
      } catch (err: any) {
        console.error("Registration Error:", err);
        const errorMessage =
          err?.data?.Error?.body ||
          (Array.isArray(err?.data?.Error) ? err.data.Error[0]?.body : null) ||
          err?.data?.message ||
          err?.data?.Message ||
          err?.message ||
          err?.error ||
          "Registration failed. Please try again.";

        toast.error(errorMessage);
      }
    }
  });
  return { formik, isLoading };
};
