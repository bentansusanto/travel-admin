import { VerifyAccountPage } from "@/modules/Authentication/Verify Account/VerifyAccountPage";

const VerifyAccount = () => {
  return <VerifyAccountPage />;
};

export default VerifyAccount;
