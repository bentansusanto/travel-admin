import { ResetPasswordPage } from "@/modules/Authentication/ResetPassword";

export default function Page() {
  return <ResetPasswordPage />;
}
