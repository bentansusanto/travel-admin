import { SalesReportPage } from "@/modules/SalesReport";

export default function SalesReportV1() {
  return <SalesReportPage />;
}
